package com.example.listview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class surat : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_surat)
        val backButton: Button = findViewById(R.id.button2)
        backButton.setOnClickListener {
            onBackPressed() // This will navigate back to the previous screen
        }
    }
}