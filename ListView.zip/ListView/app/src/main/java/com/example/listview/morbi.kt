package com.example.listview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class morbi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_morbi)
        val backButton: Button = findViewById(R.id.button4)
        backButton.setOnClickListener {
            onBackPressed() // This will navigate back to the previous screen
        }
    }
}