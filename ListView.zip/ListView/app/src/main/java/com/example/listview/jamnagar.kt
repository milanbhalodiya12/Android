package com.example.listview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class jamnagar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_jamnagar)
        val backButton: Button = findViewById(R.id.button5)
        backButton.setOnClickListener {
            onBackPressed() // This will navigate back to the previous screen
        }
    }
}