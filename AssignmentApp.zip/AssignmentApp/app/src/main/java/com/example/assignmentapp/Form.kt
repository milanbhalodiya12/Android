package com.example.assignmentapp

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.MultiAutoCompleteTextView
import java.util.*

class Form : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form)

        var emal: EditText =findViewById(R.id.editTextTextEmailAddress)
        emal.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                if(!android.util.Patterns.EMAIL_ADDRESS.matcher(p0).matches())
                {
                    emal.setError("Invalid Input")
                }
            }

            override fun afterTextChanged(p0: Editable?) {

            }

        })
        var c= Calendar.getInstance();
        //time setting
        var times: EditText = findViewById(R.id.editTextTime)

        times.setOnClickListener {
            TimePickerDialog(this, TimePickerDialog.OnTimeSetListener { timePicker, i, i2 ->
                times.setText("$i : $i2")
            },c.get(Calendar.HOUR),c.get(Calendar.MINUTE),true).show()
        }

        var dates: EditText = findViewById(R.id.editTextDate)

        dates.setOnClickListener {
            DatePickerDialog(this, DatePickerDialog.OnDateSetListener { datePicker, i, i2, i3 ->
                dates.setText("$i3/${i2+1}/$i")
            },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()
        }



        //multiline subjects
        var sub: MultiAutoCompleteTextView =findViewById(R.id.multiAutoCompleteTextView)

        var subjects= arrayOf("Java","Android","Machine learning","Node js","Asp.net")

        var subAdapt=
            ArrayAdapter<String>(this,android.R.layout.simple_selectable_list_item,subjects)
        sub.setAdapter(subAdapt)

        sub.setTokenizer(MultiAutoCompleteTextView.CommaTokenizer())

        //submit

        var sumit: Button =findViewById(R.id.submit)

        sumit.setOnClickListener {
            var red= Intent(this,MainActivity::class.java)
            startActivity(red)
        }
    }
}