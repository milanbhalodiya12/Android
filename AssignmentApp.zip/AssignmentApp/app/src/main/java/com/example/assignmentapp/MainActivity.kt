package com.example.assignmentapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var b1: Button = findViewById(R.id.button)
        var b2: Button = findViewById(R.id.button1)
        var b3: Button = findViewById(R.id.button2)
        var b4: Button = findViewById(R.id.button3)

        b1.setOnClickListener {
            var p = Intent(this,Web::class.java)
            startActivity(p);
        }

        b2.setOnClickListener {
            var form= Intent(this,Form::class.java)
            startActivity(form)
        }

        b3.setOnClickListener {
            var progress= Intent(this,progressbar::class.java)
            startActivity(progress)
        }

        b4.setOnClickListener {
            var progress= Intent(this,Imagebar::class.java)
            startActivity(progress)
        }
    }
}