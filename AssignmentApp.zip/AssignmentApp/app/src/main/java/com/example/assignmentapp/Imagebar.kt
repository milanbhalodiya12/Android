package com.example.assignmentapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import android.widget.ToggleButton

class Imagebar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_imagebar)

        var rat: RatingBar =findViewById(R.id.ratingBar)
        var txt: TextView =findViewById(R.id.textView7)
        var img: ImageView =findViewById(R.id.imageView)

        rat.setOnRatingBarChangeListener { ratingBar, fl, b ->

            txt.setText(" Rating is $fl")

        }

        var tgl: ToggleButton =findViewById(R.id.toggleButton)

        tgl.setOnClickListener {
            if(tgl.text.equals("OFF"))
            {
                img.setImageResource(R.drawable.off)
            }
            else
            {
                img.setImageResource(R.drawable.on)
            }
        }
    }
}