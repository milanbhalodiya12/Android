package com.example.assignmentapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.ProgressBar

class progressbar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_progressbar)

        var imgb: ImageButton =findViewById(R.id.imageButton)
        var prog: ProgressBar =findViewById(R.id.progressBar)

        imgb.setOnClickListener {
            Thread(Runnable {
                var count = 0;
                while (count <=100)
                {
                    count++
                    prog.setProgress(count)
                    prog.secondaryProgress = count+10;
                    Thread.sleep(10)
                }
                if(count>=100)
                {
                    var home=  Intent(this,MainActivity::class.java)
                    startActivity(home)
                }

            }).start()

        }
    }
}